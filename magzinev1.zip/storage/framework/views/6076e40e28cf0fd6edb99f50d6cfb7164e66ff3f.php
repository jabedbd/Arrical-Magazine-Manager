<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
         <div class="col-md-2">
        </div>
        <div class="col-md-10">
            <div class="panel panel-default">
                <div class="panel-heading">Admin Panel</div>

                <div class="panel-body">
                   <div class="row">
    <div class="col-md-4">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading dark-blue"><i class="fa fa-book fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content dark-blue">
          <div class="circle-tile-description text-faded">Total Issues</div>
          <div class="circle-tile-number text-faded "><?php echo e($total); ?></div>
          <a class="circle-tile-footer" href="<?php echo e(url('issue/all')); ?>">View All <i class="fa fa-chevron-circle-right"></i></a>
        </div>
      </div>
    </div>
                       
       <div class="col-md-4">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading dark-blue"><i class="fa fa-download fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content dark-blue">
          <div class="circle-tile-description text-faded">Total Downloads</div>
          <div class="circle-tile-number text-faded "><?php echo e($downloads); ?></div>
         <a class="circle-tile-footer" href="<?php echo e(url('issue/all')); ?>">View All <i class="fa fa-chevron-circle-right"></i></a>
        </div>
      </div>
    </div>
                       
       <div class="col-md-4">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading dark-blue"><i class="fa fa-eye fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content dark-blue">
          <div class="circle-tile-description text-faded">Total Views</div>
          <div class="circle-tile-number text-faded "><?php echo e($views); ?></div>
         <a class="circle-tile-footer" href="<?php echo e(url('issue/all')); ?>">View All <i class="fa fa-chevron-circle-right"></i></a>
        </div>
      </div>
    </div>

     
 
  </div> 
                </div>
                
                
            
            </div>
         <div class="row"> 
        <div class="col-md-6">
     <div class="panel panel-default">
                <div class="panel-heading">Last Issue Statistics</div>

                <div class="panel-body">
                    <div class="col-md-6">
                    <img width="100%" src="<?php echo e(url('public/cover')); ?>/<?php echo e($populer->cover); ?>"/>
                    </div>
                    <div class="col-md-6">
                        <h5>Name: <?php echo e($populer->issue); ?> </h5>
                   <h5>Total Downloads: <?php echo e($populer->download); ?></h5>
                    <h5>Total views: <?php echo e($populer->view); ?></h5>
                    <h5>Total score: <?php echo e($populer->view+$populer->download); ?></h5>
                    </div>
                    
         </div>
            </div>
        </div>
              <div class="col-md-3">
     <div class="panel panel-default">
                <div class="panel-heading">Most Viewed Issue</div>

                <div class="panel-body">
                    <a href="<?php echo e(url('issue/view')); ?>/<?php echo e($vpopuler->id); ?>">
                    <img width="100%" src="<?php echo e(url('public/cover')); ?>/<?php echo e($vpopuler->cover); ?>"/>
                        </a>
                    
         </div>
            </div>
        </div>
                 <div class="col-md-3">
     <div class="panel panel-default">
                <div class="panel-heading">Most Downloaded Issue</div>

                <div class="panel-body">
                    <a href="<?php echo e(url('issue/view')); ?>/<?php echo e($dpopuler->id); ?>">
                    <img width="100%" src="<?php echo e(url('public/cover')); ?>/<?php echo e($dpopuler->cover); ?>"/>
                        </a>
                    
         </div>
            </div>
        </div>
        </div>
        </div>
            
            
            
            
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>