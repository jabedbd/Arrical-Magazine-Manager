<?php $__env->startSection('content'); ?>
<?php if(session('show_error') != '' ): ?>
           <script>
               $.notify(
  "<?php echo e(session('show_error')); ?>",
  { position:"right bottom", className:"error" }
);
    </script>
                
                <?php /**/session(['show_error' => ''])/**/ ?>
                 <?php /**/session(['show_success' => ''])/**/ ?>
   <?php elseif(session('show_success') != '' ): ?>
           <script>
               $.notify(
  "<?php echo e(session('show_success')); ?>",
  { position:"right bottom", className:"success" }
);
    </script>
                
                <?php /**/session(['show_success' => ''])/**/ ?>
        <?php endif; ?>  
<div class="container">
    <div class="row">
         <div class="col-md-2">
        </div>
        <div class="col-md-10">
        
            <div class="panel panel-default">
                <div class="panel-heading">Edit Issue: <?php echo e($issue->issue); ?></div>
             
    <form action="<?php echo e(url('issue/edit')); ?>/<?php echo e($issue->id); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

                <div class="panel-body">
                       
                        
                          <div class="form-group">
  <label>Issue Name:</label>
  <input type="text" class="form-control" id="issue" name="issue" value="<?php echo e($issue->issue); ?>">
</div>
                                                   <div class="form-group">
  <label>Cover Page:</label>
  <input type="file" class="form-control" id="cover" name="cover">
                                                       <script>
$(document).on('ready', function() {
    $("#cover").fileinput({showCaption: false, showUpload: false});
});
</script>
</div>
                    
                       <div class="form-group">
  <label>Issue (PDF):</label>
    <input type="file" class="form-control" id="file" name="file">
                                                       <script>
$(document).on('ready', function() {
    $("#file").fileinput({showCaption: false, showUpload: false});
});
</script>
                            </div>     
                    
                     <div class="form-group">
                        <label>Description:</label> 
                         <textarea id="des" name="des" ><?php echo $issue->des; ?></textarea>
                    </div>
                    
                     <div class="form-group">
                         <label>Tags (For SEO):</label></br>
  <input type="text" class="form-control" id="tags" name="tags" data-role="tagsinput" value="<?php echo e($issue->tags); ?>">
                         
</div>

                        
                    </div>
     <div class="panel-footer settings">
        <button type="submit" class="btn btn-primary settings">Update Issue</button>
    </div>
        </form>
                </div>
            </div>
        </div>
	</div>
</div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>