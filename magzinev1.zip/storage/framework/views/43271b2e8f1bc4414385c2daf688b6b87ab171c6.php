<?php $__env->startSection('content'); ?>
<?php if(session('show_error') != '' ): ?>
           <script>
               $.notify(
  "<?php echo e(session('show_error')); ?>",
  { position:"right bottom", className:"error" }
);
    </script>
                
                <?php /**/session(['show_error' => ''])/**/ ?>
                 <?php /**/session(['show_success' => ''])/**/ ?>
   <?php elseif(session('show_success') != '' ): ?>
           <script>
               $.notify(
  "<?php echo e(session('show_success')); ?>",
  { position:"right bottom", className:"success" }
);
    </script>
                
                <?php /**/session(['show_success' => ''])/**/ ?>
        <?php endif; ?>  
<div class="container">
    <div class="row">
         <div class="col-md-2">
        </div>
        <div class="col-md-10">
        
            <div class="panel panel-default">
                <div class="panel-heading">Settings</div>
<div class="panel with-nav-tabs panel-primary">
                <div class="panel-heading">
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#tab1primary" data-toggle="tab">General</a></li>
                             <li><a href="#issue" data-toggle="tab">Issue Settings</a></li>
                            <li><a href="#tab2primary" data-toggle="tab">Social Settings</a></li>
                            
                        </ul>
                </div>
    <form action="" method="post">
        <?php echo e(csrf_field()); ?>

                <div class="panel-body">
                    <div class="tab-content">
                       
                        <div class="tab-pane fade in active" id="tab1primary">
                        
                          <div class="form-group">
  <label>Magazine Name:</label>
  <input type="text" class="form-control" id="site" name="site" value="<?php echo e($settings->magazine); ?>">
</div>
                    
                       <div class="form-group">
  <label>Address:</label>
  <input type="text" class="form-control" id="address" name="address" value="<?php echo e($settings->address); ?>">
</div>
                                        <div class="form-group">
  <label>Contact Email:</label>
  <input type="text" class="form-control" id="email" name="email" value="<?php echo e($settings->email); ?>">
</div>
                                  <div class="form-group">
  <label>Contact Number:</label>
  <input type="text" class="form-control" id="number" name="number" value="<?php echo e($settings->mobile); ?>">
</div>
                            
                        
                        
                        </div>
                        
                        <div class="tab-pane fade" id="issue">
                        
                          <div class="form-group">
  <label>Home Page Old Issue Limit:</label>
  <input type="text" class="form-control" id="old_issue" name="old_issue" value="<?php echo e($settings->old_issue); ?>">
</div>
                    
                       <div class="form-group">
  <label>Home Page Old Issue Order:</label>
     <select class="form-control" id="old_issue_type" name="old_issue_type">
    <option value="0" <?php if($settings->old_issue_type == 0): ?> selected <?php endif; ?>>Random</option>
    <option value="1" <?php if($settings->old_issue_type == 1): ?> selected <?php endif; ?>>Recent</option>
  </select>
</div>
                             <div class="form-group">
  <label>Old Issue in a Row:</label>
    <input type="text" class="form-control" id="old_item" name="old_item" value="<?php echo e($settings->old_item); ?>">

</div>
                                        <div class="form-group">
  <label>All Issue Pagination:</label>
  <input type="text" class="form-control" id="all_issue" name="all_issue" value="<?php echo e($settings->all_issue); ?>">
</div>
                                  <div class="form-group">
  <label>All Issue Order:</label>
   <select class="form-control" id="all_issue_order" name="all_issue_order">
    <option value="desc"  <?php if($settings->all_issue_order == 'desc'): ?> selected <?php endif; ?>>Descending</option>
    <option value="asc" <?php if($settings->all_issue_order == 'asc'): ?> selected <?php endif; ?>>Ascending</option>
  </select>
</div>
                            <div class="form-group">
  <label>Item in a Row:</label>
   <select class="form-control" id="item" name="item">
    <option value="5"  <?php if($settings->item == '5'): ?> selected <?php endif; ?>>2 Items</option>
    <option value="4" <?php if($settings->item == '4'): ?> selected <?php endif; ?>>3 Items</option>
    <option value="3" <?php if($settings->item == '3'): ?> selected <?php endif; ?>>4 Items</option>
    <option value="2" <?php if($settings->item == '2'): ?> selected <?php endif; ?>>5 Items</option>
  </select>
</div>
                            
                        
                        
                        </div>
                        <div class="tab-pane fade" id="tab2primary">
                        
                         <div class="form-group">
  <label>Facebook URL:</label>
  <input type="text" class="form-control" id="fb" name="fb" value="<?php echo e($settings->fb); ?>">
</div>
                             <div class="form-group">
  <label>Twitter URL:</label>
  <input type="text" class="form-control" id="tw" name="tw" value="<?php echo e($settings->tw); ?>">
</div>
                            
                             <div class="form-group">
  <label>G+ URL:</label>
  <input type="text" class="form-control" id="gplus" name="gplus" value="<?php echo e($settings->gplus); ?>">
</div>
                             <label>Pinterest URL:</label>
  <input type="text" class="form-control" id="pin" name="pin" value="<?php echo e($settings->pin); ?>">
</div>
                        
                        
                        
                        
                        
                        </div>
                        
                    </div>
     <div class="panel-footer settings">
        <button type="submit" class="btn btn-primary settings">Save Settings</button>
    </div>
        </form>
                </div>
            </div>
        </div>
	</div>
</div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>