<?php $__env->startSection('content'); ?>
<?php if(session('show_error') != '' ): ?>
           <script>
               $.notify(
  "<?php echo e(session('show_error')); ?>",
  { position:"right bottom", className:"error" }
);
    </script>
                
                <?php /**/session(['show_error' => ''])/**/ ?>
                 <?php /**/session(['show_success' => ''])/**/ ?>
   <?php elseif(session('show_success') != '' ): ?>
           <script>
               $.notify(
  "<?php echo e(session('show_success')); ?>",
  { position:"right bottom", className:"success" }
);
    </script>
                
                <?php /**/session(['show_success' => ''])/**/ ?>
        <?php endif; ?>  
<div class="container">
    <div class="row">
         <div class="col-md-2">
        </div>
        <div class="col-md-10">
        
            <div class="panel panel-default">
                <div class="panel-heading">All Issues</div>

                <div class="panel-body">
                    <script>$(document).ready(function() {
    $('#example').DataTable();
} );</script>
                  <table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Issue</th>
                <th>Cover</th>
                <th>Published Date</th>
                <th>Statistics</th>
                <th>Action</th>
                <th>Status</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
               <th>Issue</th>
                <th>Cover</th>
                <th>Published Date</th>
                <th>Statistics</th>
                <th>Action</th>
                <th>Status</th>
                
            </tr>
        </tfoot>
        <tbody>
            <?php foreach($issues as $is): ?>
            <tr>
                <td><?php echo e($is->issue); ?></td>
                <td><img width="100px" src="<?php echo e(url('public/cover')); ?>/<?php echo e($is->cover); ?>"</td>
                <td><?php echo e(date("d M Y", strtotime($is->publish_date))); ?></td>
                <td>Downloaded: <?php echo e($is->download); ?> </br> Viewed: <?php echo e($is->view); ?></td>
                <td><a href="<?php echo e(url('issue/edit')); ?>/<?php echo e($is->id); ?>" class="btn btn-primary btn-sm">
      <span class="glyphicon glyphicon-pencil"></span> Edit 
    </a> <a href="<?php echo e(url('issue/remove')); ?>/<?php echo e($is->id); ?>" class="btn btn-danger btn-sm">
      <span class="glyphicon glyphicon-trash"></span>Remove
    </a> </td>
                <td><?php if($is->status == 0): ?><a href="<?php echo e(url('issue/publish')); ?>/<?php echo e($is->id); ?>" class="btn btn-danger btn-sm">
      <span class="glyphicon glyphicon-remove"></span> Unpublished 
    </a> <?php else: ?> <a href="<?php echo e(url('issue/unpublish')); ?>/<?php echo e($is->id); ?>" class="btn btn-success btn-sm">
      <span class="glyphicon glyphicon-ok"></span> Published 
    </a> <?php endif; ?></td>
            
            </tr>
            <?php endforeach; ?>
            </tbody>
    </table>
         

                        
                    </div>
    
                </div>
            </div>
        </div>
	</div>
</div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>