<?php
if(isset($_POST['form1'])){
 $code = $_POST['code'];   
}
else {
    
    $code = '';
}

$result = false; // have we got a valid purchase code?
$our_item_id = 149180; // check if they've bought this item id.
$username = 'jabedbhuiyan'; // authors username
$api_key = 'bdy8cwjpfcgj3jj2zuwms7w8kpll52gd'; // api key from my account area
$url = "http://marketplace.envato.com/api/edge/$username/$api_key/verify-purchase:$code.json";
$ch = curl_init($url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$json_res = curl_exec($ch);
$data = json_decode($json_res,true);
$purchases = $data['verify-purchase'];
if(isset($purchases['buyer'])){
   // format single purchases same as multi purchases
   $purchases=array($purchases); 
}
$purchase_details = array();
foreach($purchases as $purchase){
    $purchase=(array)$purchase; // json issues
    if((int)$purchase['item_id']==(int)$our_item_id){
        // we have a winner!
        $result = true;
        $purchase_details = $purchase;
    }
}
// do something with the users purchase details, 
// eg: check which license they've bought, save their username something
if($result){
echo 'user has bought our item';
print_r($purchase_details);
}else{
echo 'invalid purchase code';
}
?>