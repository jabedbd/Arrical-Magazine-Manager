<?php $__env->startSection('content'); ?>
<?php if(session('show_error') != '' ): ?>
           <script>
               $.notify(
  "<?php echo e(session('show_error')); ?>",
  { position:"right bottom", className:"error" }
);
    </script>
                
                <?php /**/session(['show_error' => ''])/**/ ?>
                 <?php /**/session(['show_success' => ''])/**/ ?>
   <?php elseif(session('show_success') != '' ): ?>
           <script>
               $.notify(
  "<?php echo e(session('show_success')); ?>",
  { position:"right bottom", className:"success" }
);
    </script>
                
                <?php /**/session(['show_success' => ''])/**/ ?>
        <?php endif; ?>  
<div class="container">
    <div class="row">
         <div class="col-md-2">
        </div>
        <div class="col-md-10">
        
            <div class="panel panel-default">
                <div class="panel-heading">Static Pages</div>
<div class="panel with-nav-tabs panel-primary">
                <div class="panel-heading">
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#tab1primary" data-toggle="tab">About Us</a></li>
                            
                        </ul>
                </div>
    <form action="" method="post">
        <?php echo e(csrf_field()); ?>

                <div class="panel-body">
                    <div class="tab-content">
                       
                        <div class="tab-pane fade in active" id="tab1primary">
                        
 <textarea rows="15" name="content"><?php echo $about->content; ?></textarea>              
                        
                        
                        </div>
                        <div class="tab-pane fade" id="tab2primary">
                        
</div>
                        
                        
                        
                        
                        
                        </div>
                        
                    </div>
     <div class="panel-footer settings">
        <button type="submit" class="btn btn-primary settings">Save Page</button>
    </div>
        </form>
                </div>
            </div>
        </div>
	</div>
</div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>