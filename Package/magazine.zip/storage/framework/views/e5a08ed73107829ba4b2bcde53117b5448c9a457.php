<?php $__env->startSection('content'); ?>
<div class="container-full">
<div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading text-center">All Issues</div>

                <div class="panel-body">
                    <div class="row">
                    <div class="col-md-1"></div>
                    <div class="col-md-10 old-bg ">
                        <?php if($result > '0'): ?>
                        <?php foreach($all as $issue): ?>
                <div class="col-md-4 top-buffer">
                    <a href="<?php echo e(url('view/issue')); ?>/<?php echo e($issue->id); ?>">
      <img width="100%" src="<?php echo e(url('public/cover')); ?>/<?php echo e($issue->cover); ?>" alt="<?php echo e($issue->issue); ?>">
                        </a>
                   <a href="<?php echo e(url('view/issue')); ?>/<?php echo e($issue->id); ?>" class="btn btn-primary btn-block" ><?php echo e($issue->issue); ?></a>
    </div>
                        <?php endforeach; ?>
   <?php else: ?> 
            Nothing Found!
                        <?php endif; ?>
                                 
                    </div>
                   
                           </div>
                    <div class="panel-footer page-bg">
                    <div class="row">
                    <div class="col-md-1"></div>
                    <div class="col-md-10 page-bg">
                     <?php echo e($all->links()); ?> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>