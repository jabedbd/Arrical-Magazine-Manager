<?php $__env->startSection('content'); ?>
<div class="container-full">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading text-center">Latest Issue</div>

                <div class="panel-body">
                   
                       <div class="col-md-4"></div>
                    <div class="col-md-4">
                        <div class="letest-cover">
                            <a href="view/issue/<?php echo e($latest->id); ?>">
                       <img width="100%" src="<?php echo e(url('public/cover/')); ?>/<?php echo e($latest->cover); ?>" />
                       </a>
                       </div>
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading text-center">Old Issues</div>

                <div class="panel-body">
                    <div class="col-md-1"></div>
                    <div class="col-md-10 old-bg">
                      <div id="old-issue" class="owl-demo">
                 <?php foreach($old as $ol): ?>
                <div class="item">
                    <a href="view/issue/<?php echo e($ol->id); ?>">
                  <img width="100%" src="<?php echo e(url('public/cover')); ?>/<?php echo e($ol->cover); ?>" alt="<?php echo e($ol->issue); ?>"></a>
                   <a href="view/issue/<?php echo e($latest->id); ?>" class="btn btn-primary btn-block" ><?php echo e($ol->issue); ?></a>
                </div>
                          <?php endforeach; ?>
          

              </div>

                                         
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>