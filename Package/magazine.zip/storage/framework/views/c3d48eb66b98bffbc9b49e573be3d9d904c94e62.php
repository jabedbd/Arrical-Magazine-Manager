<?php $__env->startSection('content'); ?>
<script>
$(document).ready(function() {
  $("#bookmarkme").click(function() {
    if (window.sidebar) { // Mozilla Firefox Bookmark
      window.sidebar.addPanel(location.href,document.title,"");
    } else if(window.external) { // IE Favorite
      window.external.AddFavorite(location.href,document.title); }
    else if(window.opera && window.print) { // Opera Hotlist
      this.title=document.title;
      return true;
    }
  });
});

</script>
<meta property="og:url"           content="<?php echo e(url('view/issue/')); ?>/<?php echo e($issue->id); ?>" />
	<meta property="og:type"          content="website" />
	<meta property="og:title"         content="<?php echo e($issue->issue); ?>" />
	<meta property="og:description"   content="<?php echo e($issue->des); ?>" />
	<meta property="og:image"         content="<?php echo e(url('public/cover')); ?>/<?php echo e($issue->cover); ?>" />
<div class="container-full">
<div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading text-center">ISSUE: <?php echo e($issue->issue); ?></div>

                <div class="panel-body">
                    <div class="row">
                    <div class="col-md-1"></div>
                    <div class="col-md-5 old-bg ">
                       <div class="responsive-video">
                      <embed src="<?php echo e(url('public/web')); ?>/<?php echo e($issue->file); ?>" width="100%" height="auto" type='application/pdf'>
                        </div>
                       <div class="col-md-1"></div>                   
                    </div>
                         <div class="col-md-5 dt-bg">
                        </br>
                        Issue: <?php echo e($issue->issue); ?> </br></br>
                        Published on: <?php echo e(date("d M Y", strtotime($issue->publish_date))); ?> </br></br>
                        Total Views: <?php echo e($issue->view); ?> </br></br>
                        Total Downloads: <?php echo e($issue->download); ?> </br></br>
                         <a class="btn btn-primary shadow" href="<?php echo e(url('public/web/viewer.html?file=')); ?><?php echo e($issue->file); ?>">Read in Full Screen</a>
                         <a class="btn btn-primary shadow" href="<?php echo e(url('download/issue/')); ?>/<?php echo e($issue->id); ?>" >Download</a>
                         <a class="btn btn-primary shadow" id="bookmarkme" href="#" rel="sidebar" title="<?php echo e($issue->issue); ?>">Add to Favorite</a> </br> </br>
<div class="panel panel-default">
<div class="panel-heading text-center">Description</div>
   
</div>
<div class="des">
 <?php echo $issue->des; ?>

</div>
<div class="panel panel-default">
<div class="panel-heading text-center">Share with Friends</div>
</div>
<center><a href="https://web.facebook.com/sharer.php?u=<?php echo e(url('view/issue/')); ?>/<?php echo e($issue->id); ?>" target="_blank" class="btn-social btn-facebook"><i class="fa fa-facebook"></i></a>
<a href="https://plus.google.com/share?url=<?php echo e(url('view/issue/')); ?>/<?php echo e($issue->id); ?>" target="_blank" class="btn-social btn-google-plus"><i class="fa fa-google-plus"></i></a>
<a href="http://twitter.com/intent/tweet?text=<?php echo e($issue->issue); ?>&url=<?php echo e(url('view/issue/')); ?>/<?php echo e($issue->id); ?>" target="_blank" class="btn-social btn-twitter"><i class="fa fa-twitter"></i></a></center>
 
                             
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>